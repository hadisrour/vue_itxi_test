# vue_itxi_test


## Installation

```
unzip vue-itxi-test

open command prompt

type "cd path/to/vue_itxi_test"

type "npm install"

type "npm run serve"

```
now open your browser and go to localhost:8080

ALL DONE.




