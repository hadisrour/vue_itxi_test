module.exports = {
    lintOnSave: false,
    productionSourceMap: false,
};
